package member2;

public class ManSess {
}
